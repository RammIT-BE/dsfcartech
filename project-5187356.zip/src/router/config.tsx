import { lazy } from 'react';
import { RouteObject } from 'react-router-dom';

const HomePage = lazy(() => import('../pages/home/page'));
const AboutPage = lazy(() => import('../pages/about/page'));
const ContactPage = lazy(() => import('../pages/contact/page'));
const RealisatiesPage = lazy(() => import('../pages/realisaties/page'));
const DienstenPage = lazy(() => import('../pages/diensten/page'));
const AdminLoginPage = lazy(() => import('../pages/admin/login/page'));
const AdminRealisatiesPage = lazy(() => import('../pages/admin/realisaties/page'));
const NotFoundPage = lazy(() => import('../pages/NotFound'));

const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/over-ons-auto-elektronica-antwerpen',
    element: <AboutPage />,
  },
  {
    path: '/contact-afspraak-antwerpen',
    element: <ContactPage />,
  },
  {
    path: '/realisaties-auto-upgrades-antwerpen',
    element: <RealisatiesPage />,
  },
  {
    path: '/diensten-auto-upgrades-antwerpen',
    element: <DienstenPage />,
  },
  {
    path: '/admin/login',
    element: <AdminLoginPage />,
  },
  {
    path: '/admin/realisaties',
    element: <AdminRealisatiesPage />,
  },
  {
    path: '*',
    element: <NotFoundPage />,
  },
];

export default routes;

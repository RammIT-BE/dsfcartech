import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Scroll to top functionality
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      {/* Appointment Notice Bar */}
      <div className="bg-black text-white py-2 px-4 text-center relative z-50 border-b border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center space-x-2 text-xs sm:text-sm font-medium">
            <i className="ri-calendar-check-line text-base sm:text-lg"></i>
            <span className="hidden sm:inline">⚠️ Enkel op afspraak - Bel 0489 17 05 92 voor een afspraak</span>
            <span className="sm:hidden">⚠️ Enkel op afspraak</span>
            <a 
              href="tel:0489170592" 
              className="ml-2 sm:ml-4 px-3 sm:px-4 py-1 sm:py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs sm:text-sm rounded-full hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer font-medium"
            >
              Bel Nu
            </a>
          </div>
        </div>
      </div>

      <nav 
        className={`fixed left-0 right-0 z-40 transition-all duration-500 ${
          isScrolled 
            ? 'top-0 bg-black/95 backdrop-blur-xl shadow-2xl shadow-cyan-500/10' 
            : 'top-8 bg-gradient-to-b from-black/80 to-transparent backdrop-blur-sm'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2 sm:space-x-3 group">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg blur-lg opacity-0 group-hover:opacity-75 transition-opacity duration-500"></div>
                <img 
                  src="https://static.readdy.ai/image/9e62058216dff63d1a686833c97014ce/b15c0384c219f0e7f5770236ff515156.png" 
                  alt="DSF Cartech Logo" 
                  className="h-12 sm:h-16 w-auto relative z-10 transition-transform duration-500 group-hover:scale-110"
                />
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-1">
              <Link
                to="/"
                className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-300 hover:scale-105 whitespace-nowrap ${
                  location.pathname === '/'
                    ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                Home
              </Link>

              <Link
                to="/diensten-auto-upgrades-antwerpen"
                className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-300 hover:scale-105 whitespace-nowrap ${
                  location.pathname === '/diensten-auto-upgrades-antwerpen'
                    ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                Diensten
              </Link>

              <Link
                to="/realisaties-auto-upgrades-antwerpen"
                className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-300 hover:scale-105 whitespace-nowrap ${
                  location.pathname === '/realisaties-auto-upgrades-antwerpen'
                    ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                Realisaties
              </Link>

              <Link
                to="/over-ons-auto-elektronica-antwerpen"
                className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-300 hover:scale-105 whitespace-nowrap ${
                  location.pathname === '/over-ons-auto-elektronica-antwerpen'
                    ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                Over Ons
              </Link>

              <Link
                to="/contact-afspraak-antwerpen"
                className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-300 hover:scale-105 whitespace-nowrap ${
                  location.pathname === '/contact-afspraak-antwerpen'
                    ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                    : 'text-gray-300 hover:text-white hover:bg-white/10'
                }`}
              >
                Contact
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button 
              onClick={toggleMobileMenu}
              className="lg:hidden text-white p-2 hover:bg-white/10 rounded-lg transition-colors duration-300 cursor-pointer"
              aria-label="Menu"
            >
              <i className={`text-2xl transition-transform duration-300 ${isMobileMenuOpen ? 'ri-close-line rotate-90' : 'ri-menu-line'}`}></i>
            </button>
          </div>
        </div>

        {/* Animated bottom border */}
        <div className={`h-px bg-gradient-to-r from-transparent via-cyan-500 to-transparent transition-opacity duration-500 ${
          isScrolled ? 'opacity-100' : 'opacity-0'
        }`}></div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div 
        className={`fixed inset-0 bg-black/80 backdrop-blur-sm z-30 lg:hidden transition-opacity duration-300 ${
          isMobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={toggleMobileMenu}
      ></div>

      {/* Mobile Menu */}
      <div 
        className={`fixed top-0 right-0 h-full w-full sm:w-80 bg-black/95 backdrop-blur-xl z-40 lg:hidden transform transition-transform duration-300 ease-in-out ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full pt-24 sm:pt-32 px-6">
          {/* Mobile Navigation Links */}
          <div className="flex flex-col space-y-2">
            <Link
              to="/"
              className={`px-6 py-4 rounded-xl font-medium transition-all duration-300 ${
                location.pathname === '/'
                  ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center space-x-3">
                <i className="ri-home-line text-xl"></i>
                <span>Home</span>
              </div>
            </Link>

            <Link
              to="/diensten-auto-upgrades-antwerpen"
              className={`px-6 py-4 rounded-xl font-medium transition-all duration-300 ${
                location.pathname === '/diensten-auto-upgrades-antwerpen'
                  ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center space-x-3">
                <i className="ri-tools-line text-xl"></i>
                <span>Diensten</span>
              </div>
            </Link>

            <Link
              to="/realisaties-auto-upgrades-antwerpen"
              className={`px-6 py-4 rounded-xl font-medium transition-all duration-300 ${
                location.pathname === '/realisaties-auto-upgrades-antwerpen'
                  ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center space-x-3">
                <i className="ri-gallery-line text-xl"></i>
                <span>Realisaties</span>
              </div>
            </Link>

            <Link
              to="/over-ons-auto-elektronica-antwerpen"
              className={`px-6 py-4 rounded-xl font-medium transition-all duration-300 ${
                location.pathname === '/over-ons-auto-elektronica-antwerpen'
                  ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center space-x-3">
                <i className="ri-team-line text-xl"></i>
                <span>Over Ons</span>
              </div>
            </Link>

            <Link
              to="/contact-afspraak-antwerpen"
              className={`px-6 py-4 rounded-xl font-medium transition-all duration-300 ${
                location.pathname === '/contact-afspraak-antwerpen'
                  ? 'text-white bg-gradient-to-r from-cyan-500 to-blue-600 shadow-lg shadow-cyan-500/30'
                  : 'text-gray-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center space-x-3">
                <i className="ri-mail-line text-xl"></i>
                <span>Contact</span>
              </div>
            </Link>
          </div>

          {/* Mobile CTA Button */}
          <div className="mt-8">
            <a
              href="tel:0489170592"
              className="flex items-center justify-center space-x-3 px-6 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold rounded-xl shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 transition-all duration-300 cursor-pointer"
            >
              <i className="ri-phone-line text-xl"></i>
              <span>0489 17 05 92</span>
            </a>
          </div>

          {/* Mobile Menu Footer */}
          <div className="mt-auto pb-8 text-center">
            <p className="text-gray-400 text-sm">
              Antwerpen's #1 Auto-Elektronica
            </p>
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white p-3 rounded-full shadow-lg hover:shadow-orange-500/50 transition-all duration-300 transform hover:scale-110 z-50 group cursor-pointer"
          aria-label="Scroll naar boven"
        >
          <i className="ri-arrow-up-line text-xl group-hover:animate-bounce"></i>
        </button>
      )}
    </>
  );
}

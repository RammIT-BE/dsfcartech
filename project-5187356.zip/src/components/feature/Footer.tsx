import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Link } from 'react-router-dom';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

export default function Footer() {
  const currentYear = new Date().getFullYear();
  const [footerData, setFooterData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFooterContent();
  }, []);

  const loadFooterContent = async () => {
    try {
      const { data, error } = await supabase
        .from('footer_content')
        .select('*')
        .eq('is_active', true)
        .order('display_order');

      if (error) throw error;
      if (data) setFooterData(data);
    } catch (error) {
      console.error('Error loading footer:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSection = (sectionName: string) => {
    return footerData.find(s => s.section_name === sectionName);
  };

  const brandSection = getSection('brand');
  const servicesSection = getSection('services');
  const companySection = getSection('company');
  const contactSection = getSection('contact');
  const socialSection = getSection('social');
  const bottomSection = getSection('bottom');

  if (loading) {
    return (
      <footer className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <div className="w-8 h-8 border-4 border-cyan-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
        </div>
      </footer>
    );
  }

  return (
    <footer className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white overflow-hidden">
      {/* Subtle Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }}></div>
      </div>

      {/* Top Accent Line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 relative z-10">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand Section */}
          {brandSection && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="lg:col-span-1"
            >
              {brandSection.title && (
                <h4 className="text-lg font-semibold mb-4 text-white">{brandSection.title}</h4>
              )}

              {Array.isArray(brandSection.items) && brandSection.items.map((item: any, index: number) => (
                <div key={index} className="mb-6">
                  {item.type === 'logo' && (
                    <div className="group">
                      <div className="relative inline-block">
                        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl blur-xl opacity-0 group-hover:opacity-50 transition-opacity duration-500"></div>
                        <img 
                          src={item.url} 
                          alt={item.alt || 'Logo'} 
                          className="h-20 w-auto relative z-10 transition-transform duration-500 group-hover:scale-105"
                        />
                      </div>
                    </div>
                  )}
                  {item.type === 'text' && (
                    <p className="text-gray-300 text-sm leading-relaxed">{item.content}</p>
                  )}
                </div>
              ))}
              
              {/* Social Icons */}
              {socialSection && Array.isArray(socialSection.items) && (
                <div className="flex gap-3">
                  {socialSection.items.map((social: any, index: number) => (
                    <motion.a
                      key={index}
                      href={social.href || '#'}
                      whileHover={{ scale: 1.1, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      className="w-10 h-10 flex items-center justify-center bg-gradient-to-br from-cyan-500/10 to-blue-500/10 hover:from-cyan-500/20 hover:to-blue-500/20 border border-cyan-500/30 hover:border-cyan-400/50 rounded-xl transition-all duration-300 cursor-pointer hover:shadow-lg hover:shadow-cyan-500/30"
                    >
                      <i className={`${social.icon} text-lg text-cyan-400 hover:text-cyan-300 transition-colors duration-300`}></i>
                    </motion.a>
                  ))}
                </div>
              )}
            </motion.div>
          )}

          {/* Diensten */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">Diensten</h3>
            <ul className="space-y-3">
              <li>
                <Link
                  to="/diensten-auto-upgrades-antwerpen"
                  className="text-gray-300 hover:text-cyan-400 transition-colors duration-300 cursor-pointer"
                >
                  CarPlay & Android Auto
                </Link>
              </li>
              <li>
                <Link
                  to="/diensten-auto-upgrades-antwerpen"
                  className="text-gray-300 hover:text-cyan-400 transition-colors duration-300 cursor-pointer"
                >
                  Sterrenhemel
                </Link>
              </li>
              <li>
                <Link
                  to="/diensten-auto-upgrades-antwerpen"
                  className="text-gray-300 hover:text-cyan-400 transition-colors duration-300 cursor-pointer"
                >
                  Sfeerverlichting
                </Link>
              </li>
              <li>
                <Link
                  to="/diensten-auto-upgrades-antwerpen"
                  className="text-gray-300 hover:text-cyan-400 transition-colors duration-300 cursor-pointer"
                >
                  Achteruitrijcamera
                </Link>
              </li>
              <li>
                <Link
                  to="/diensten-auto-upgrades-antwerpen"
                  className="text-gray-300 hover:text-cyan-400 transition-colors duration-300 cursor-pointer"
                >
                  Android Schermen
                </Link>
              </li>
            </ul>
          </div>

          {/* Company Section */}
          {companySection && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h4 className="text-lg font-semibold mb-4 text-white">{companySection.title}</h4>
              <ul className="space-y-3">
                {Array.isArray(companySection.items) && companySection.items.map((link: any, index: number) => (
                  <li key={index}>
                    <a
                      href={link.href || '#'}
                      className="text-gray-300 hover:text-cyan-400 text-sm transition-all duration-300 flex items-center gap-2 group cursor-pointer hover:translate-x-1"
                    >
                      <i className="ri-arrow-right-s-line text-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300"></i>
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>
          )}

          {/* Contact Section */}
          {contactSection && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
            >
              <h4 className="text-lg font-semibold mb-4 text-white">{contactSection.title}</h4>
              <ul className="space-y-3">
                {Array.isArray(contactSection.items) && contactSection.items.map((item: any, index: number) => (
                  <li key={index} className="flex items-start gap-3 text-gray-300 text-sm group">
                    <i className={`${item.icon} text-cyan-400 mt-0.5 group-hover:scale-110 transition-transform duration-300`}></i>
                    <span className="group-hover:text-white transition-colors duration-300">{item.text}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          )}
        </div>

        {/* Bottom Bar */}
        {bottomSection && (
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
            className="pt-8 border-t border-white/10"
          >
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              {Array.isArray(bottomSection.items) && bottomSection.items.map((item: any, index: number) => {
                if (item.type === 'copyright') {
                  return (
                    <p key={index} className="text-gray-400 text-sm">
                      {item.text.replace('2024', currentYear.toString())}
                    </p>
                  );
                }
                
                if (item.type === 'links') {
                  return (
                    <div key={index} className="flex items-center gap-6">
                      <div className="flex gap-6 text-sm">
                        {Array.isArray(item.items) && item.items.map((link: any, linkIndex: number) => (
                          <a key={linkIndex} href={link.href || '#'} className="text-gray-400 hover:text-cyan-400 transition-all duration-300 cursor-pointer hover:scale-105">
                            {link.name}
                          </a>
                        ))}
                      </div>
                    </div>
                  );
                }
                
                if (item.type === 'developer') {
                  return (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-400">
                      <span>{item.text}</span>
                      <a href={item.href || '#'} target="_blank" rel="noopener noreferrer" className="cursor-pointer hover:opacity-80 transition-all duration-300 hover:scale-105">
                        <img 
                          src={item.logo} 
                          alt="Developer" 
                          className="h-6 w-auto"
                        />
                      </a>
                    </div>
                  );
                }
                
                return null;
              })}
            </div>
          </motion.div>
        )}
      </div>
    </footer>
  );
}
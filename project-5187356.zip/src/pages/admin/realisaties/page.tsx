import { useState, useEffect } from 'react';
import { supabase } from '../../../lib/supabase';
import { motion } from 'framer-motion';

interface Realisatie {
  id: number;
  image_url: string;
  created_at: string;
}

export default function AdminRealisatiesPage() {
  const [realisaties, setRealisaties] = useState<Realisatie[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      fetchRealisaties();
    }
  }, [isAuthenticated]);

  const checkAuth = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) {
        console.error('Auth error:', error);
        setCheckingAuth(false);
        setIsAuthenticated(false);
        window.REACT_APP_NAVIGATE('/admin/login');
        return;
      }
      
      if (!session) {
        setCheckingAuth(false);
        setIsAuthenticated(false);
        window.REACT_APP_NAVIGATE('/admin/login');
        return;
      }

      // Verify session is still valid
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        console.error('User verification error:', userError);
        setCheckingAuth(false);
        setIsAuthenticated(false);
        await supabase.auth.signOut();
        window.REACT_APP_NAVIGATE('/admin/login');
        return;
      }
      
      setIsAuthenticated(true);
      setCheckingAuth(false);
    } catch (error) {
      console.error('Unexpected auth error:', error);
      setCheckingAuth(false);
      setIsAuthenticated(false);
      window.REACT_APP_NAVIGATE('/admin/login');
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Logout error:', error);
    }
    window.REACT_APP_NAVIGATE('/admin/login');
  };

  const fetchRealisaties = async () => {
    try {
      const { data, error } = await supabase
        .from('realisaties')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRealisaties(data || []);
    } catch (error) {
      console.error('Error fetching realisaties:', error);
      alert('Fout bij het laden van foto\'s. Controleer je internetverbinding.');
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(files);
  };

  const uploadImages = async () => {
    if (selectedFiles.length === 0) {
      alert('Selecteer minimaal één foto');
      return;
    }

    setUploading(true);
    
    try {
      for (const file of selectedFiles) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `${fileName}`;

        // Upload naar storage
        const { error: uploadError } = await supabase.storage
          .from('realisaties')
          .upload(filePath, file, {
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) throw uploadError;

        // Haal public URL op
        const { data: { publicUrl } } = supabase.storage
          .from('realisaties')
          .getPublicUrl(filePath);

        // Voeg toe aan database met alle verplichte velden
        const { error: dbError } = await supabase
          .from('realisaties')
          .insert([{ 
            image_url: publicUrl,
            title: `Foto ${Date.now()}`,
            description: '',
            service_type: 'algemeen',
            car_model: 'Onbekend'
          }]);

        if (dbError) throw dbError;
      }

      alert(`${selectedFiles.length} foto's succesvol toegevoegd!`);
      setSelectedFiles([]);
      fetchRealisaties();
    } catch (error) {
      console.error('Error uploading images:', error);
      alert('Er is een fout opgetreden bij het uploaden');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: number, imageUrl: string) => {
    if (!confirm('Weet je zeker dat je deze foto wilt verwijderen?')) {
      return;
    }

    try {
      // Verwijder uit storage
      if (imageUrl && imageUrl.includes('supabase')) {
        const path = imageUrl.split('/').pop();
        if (path) {
          await supabase.storage
            .from('realisaties')
            .remove([path]);
        }
      }

      // Verwijder uit database
      const { error } = await supabase
        .from('realisaties')
        .delete()
        .eq('id', id);

      if (error) throw error;
      fetchRealisaties();
    } catch (error) {
      console.error('Error deleting photo:', error);
      alert('Er is een fout opgetreden bij het verwijderen');
    }
  };

  if (checkingAuth || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-cyan-500 border-t-transparent mb-4"></div>
          <p className="text-white">Authenticatie controleren...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Header */}
      <div className="bg-black/50 backdrop-blur-xl border-b border-white/10 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 flex items-center justify-center bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl">
              <i className="ri-image-line text-2xl text-white"></i>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Foto's Beheer</h1>
              <p className="text-sm text-gray-400">Upload en beheer je foto's</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-logout-box-line mr-2"></i>
            Uitloggen
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Upload Section */}
        <div className="mb-8 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-6">
          <h2 className="text-xl font-bold text-white mb-4">Foto's Uploaden</h2>
          
          <label className="block mb-4">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            <div className="w-full px-4 py-8 bg-white/5 border-2 border-dashed border-white/20 hover:border-cyan-500/50 rounded-lg cursor-pointer transition-colors text-center">
              <i className="ri-upload-cloud-line text-4xl text-cyan-400 mb-2"></i>
              <p className="text-white font-medium mb-1">Klik om foto's te selecteren</p>
              <p className="text-xs text-gray-400">Of sleep bestanden hierheen</p>
              <p className="text-xs text-gray-500 mt-2">Meerdere foto's tegelijk mogelijk</p>
            </div>
          </label>

          {selectedFiles.length > 0 && (
            <div className="mb-4">
              <p className="text-sm text-gray-300 mb-3">
                {selectedFiles.length} foto's geselecteerd
              </p>
              <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 mb-4">
                {selectedFiles.map((file, index) => (
                  <div key={index} className="relative group aspect-square">
                    <img
                      src={URL.createObjectURL(file)}
                      alt={file.name}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  </div>
                ))}
              </div>
              <button
                onClick={uploadImages}
                disabled={uploading}
                className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {uploading ? (
                  <>
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Uploaden...
                  </>
                ) : (
                  <>
                    <i className="ri-upload-line mr-2"></i>
                    Upload {selectedFiles.length} foto's
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="mb-6 text-white">
          <p className="text-lg">Totaal: <span className="font-bold text-cyan-400">{realisaties.length}</span> foto's</p>
        </div>

        {/* Photo Grid */}
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-cyan-500 border-t-transparent"></div>
            <p className="mt-4 text-gray-400">Laden...</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {realisaties.map((realisatie) => (
              <motion.div
                key={realisatie.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative group aspect-square bg-white/5 backdrop-blur-xl rounded-lg border border-white/10 overflow-hidden hover:border-cyan-500/50 transition-all duration-300"
              >
                <img
                  src={realisatie.image_url}
                  alt={`Foto ${realisatie.id}`}
                  className="w-full h-full object-cover"
                />
                
                {/* Delete Button */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <button
                    onClick={() => handleDelete(realisatie.id, realisatie.image_url)}
                    className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-delete-bin-line mr-2"></i>
                    Verwijderen
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {realisaties.length === 0 && !loading && (
          <div className="text-center py-20">
            <i className="ri-image-line text-6xl text-gray-600 mb-4"></i>
            <p className="text-gray-400 text-lg">Nog geen foto's toegevoegd</p>
          </div>
        )}
      </div>
    </div>
  );
}

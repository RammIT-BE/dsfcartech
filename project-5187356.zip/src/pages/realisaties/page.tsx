
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Navigation from '../../components/feature/Navigation';
import Footer from '../../components/feature/Footer';
import SEOHead from '../../components/SEOHead';
import { supabase } from '../../lib/supabase';

interface Realisatie {
  id: number;
  image_url: string;
  created_at: string;
}

export default function RealisatiesPage() {
  const [realisaties, setRealisaties] = useState<Realisatie[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    fetchRealisaties();
  }, []);

  const fetchRealisaties = async () => {
    try {
      const { data, error } = await supabase
        .from('realisaties')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRealisaties(data || []);
    } catch (error) {
      console.error('Error fetching realisaties:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Laden...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <SEOHead
        title="Realisaties Auto Upgrades Antwerpen | CarPlay Sterrenhemel Camera Installaties"
        description="Bekijk onze professionele auto upgrade realisaties in Antwerpen. CarPlay installaties, sterrenhemel, sfeerverlichting en camera systemen. 4.9 sterren op Google Reviews."
        keywords="auto upgrades antwerpen, carplay installatie, sterrenhemel auto, backup camera, sfeerverlichting auto, realisaties"
      />
      
      <div className="min-h-screen bg-white">
        <Navigation />
        
        {/* Hero Section */}
        <section className="pt-32 pb-16 px-4 bg-gradient-to-b from-gray-50 to-white">
          <div className="max-w-7xl mx-auto text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-6xl font-bold mb-6"
            >
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
                Onze Realisaties
              </span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-xl text-gray-600 max-w-3xl mx-auto"
            >
              Bekijk de transformaties die we hebben gerealiseerd voor onze klanten
            </motion.p>
          </div>
        </section>

        {/* Photo Grid */}
        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {realisaties.map((realisatie, index) => (
                <motion.div
                  key={realisatie.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => setSelectedImage(realisatie.image_url)}
                  className="relative group cursor-pointer overflow-hidden rounded-lg shadow-md hover:shadow-2xl transition-all duration-300 aspect-square"
                >
                  <img
                    src={realisatie.image_url}
                    alt={`Realisatie ${realisatie.id}`}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  
                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <i className="ri-zoom-in-line text-4xl text-white"></i>
                  </div>
                </motion.div>
              ))}
            </div>

            {realisaties.length === 0 && (
              <div className="text-center py-20">
                <i className="ri-image-line text-6xl text-gray-300 mb-4"></i>
                <p className="text-gray-500 text-lg">Nog geen foto's toegevoegd</p>
              </div>
            )}
          </div>
        </section>

        {/* Lightbox Modal */}
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImage(null)}
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4 cursor-zoom-out"
          >
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-6 right-6 w-12 h-12 flex items-center justify-center bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors z-10"
            >
              <i className="ri-close-line text-2xl"></i>
            </button>

            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="max-w-6xl max-h-[90vh] relative"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={selectedImage}
                alt="Realisatie"
                className="max-w-full max-h-[90vh] object-contain rounded-lg"
              />
            </motion.div>
          </motion.div>
        )}

        <Footer />
      </div>
    </>
  );
}

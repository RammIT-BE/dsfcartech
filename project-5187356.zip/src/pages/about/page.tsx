import { motion } from 'framer-motion';
import Navigation from '../../components/feature/Navigation';
import Footer from '../../components/feature/Footer';
import SEOHead from '../../components/SEOHead';

export default function AboutPage() {
  const siteUrl = import.meta.env.VITE_SITE_URL || 'https://dsfcartech.be';

  const schema = {
    "@context": "https://schema.org",
    "@type": "AboutPage",
    "name": "Over DSF Cartech",
    "description": "DSF Cartech is gespecialiseerd in professionele auto-upgrades in Antwerpen. Van CarPlay tot sfeerverlichting - wij transformeren uw auto.",
    "url": `${siteUrl}/over-ons-auto-elektronica-antwerpen`,
  };

  return (
    <>
      <SEOHead
        title="Over Ons - DSF Cartech Auto Elektronica Antwerpen"
        description="DSF Cartech is uw specialist in auto elektronica upgrades in Antwerpen. Professionele installatie van CarPlay, Android Auto, sfeerverlichting, sterrenhemel en meer. Ervaren team met passie voor automotive technologie."
        keywords="over ons, DSF Cartech, auto elektronica Antwerpen, CarPlay specialist, Android Auto installatie, auto upgrades Antwerpen, automotive technologie"
      />
      
      <div className="bg-black text-white min-h-screen">
        <Navigation />
        
        {/* Hero Section */}
        <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(6, 182, 212, 0.3) 1px, transparent 0)',
              backgroundSize: '50px 50px'
            }}></div>
          </div>

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black"></div>

          {/* Content */}
          <div className="relative z-10 max-w-4xl mx-auto px-6 text-center py-20">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
                Over <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">DSF Cartech</span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
                Uw specialist in premium auto elektronica upgrades in Antwerpen
              </p>
            </motion.div>
          </div>

          {/* Bottom Gradient */}
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent"></div>
        </section>

        {/* Why DSF Cartech Section */}
        <section className="py-12 md:py-16 px-4 bg-gradient-to-b from-gray-900 to-black">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl md:text-4xl font-bold text-center mb-8 md:mb-12 text-white">
              Waarom DSF Cartech?
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {[
                {
                  icon: 'ri-shield-check-line',
                  title: '2 Jaar Garantie',
                  description: 'Volledige garantie op alle installaties en materialen'
                },
                {
                  icon: 'ri-flashlight-line',
                  title: 'Installatie in 1 Dag',
                  description: 'Snelle en professionele service zonder lange wachttijden'
                },
                {
                  icon: 'ri-star-line',
                  title: '4.9 Sterren Reviews',
                  description: 'Uitstekend beoordeeld door 41+ tevreden klanten'
                },
                {
                  icon: 'ri-tools-line',
                  title: 'Gecertificeerde Technici',
                  description: 'Jarenlange ervaring in auto-elektronica installaties'
                },
                {
                  icon: 'ri-price-tag-3-line',
                  title: 'Transparante Prijzen',
                  description: 'Geen verborgen kosten, duidelijke offerte vooraf'
                },
                {
                  icon: 'ri-customer-service-2-line',
                  title: 'Persoonlijk Advies',
                  description: 'Maatwerk oplossingen perfect afgestemd op uw wensen'
                }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 md:p-8 hover:border-cyan-500/50 transition-all duration-300"
                >
                  <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mb-4 md:mb-6">
                    <i className={`${feature.icon} text-white text-xl md:text-3xl`}></i>
                  </div>
                  <h3 className="text-lg md:text-xl font-bold mb-2 md:mb-3 text-white">{feature.title}</h3>
                  <p className="text-sm md:text-base text-gray-300 leading-relaxed">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Location Section */}
        <section className="py-12 md:py-16 px-4 bg-gradient-to-b from-black to-gray-900">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl md:text-4xl font-bold text-center mb-8 md:mb-12 text-white">
              Onze Werkplaats
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6 md:gap-8">
              {/* Map */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden h-64 md:h-96"
              >
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2498.123456789!2d4.4025!3d51.2194!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTHCsDEzJzA5LjgiTiA0wrAyNCcwOS4wIkU!5e0!3m2!1snl!2sbe!4v1234567890"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="DSF Cartech Locatie"
                ></iframe>
              </motion.div>

              {/* Contact Info */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 md:p-8 flex flex-col justify-center"
              >
                <h3 className="text-xl md:text-2xl font-bold mb-6 md:mb-8 text-white">Bezoek Ons</h3>
                
                <div className="space-y-4 md:space-y-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-map-pin-line text-white text-lg md:text-xl"></i>
                    </div>
                    <div>
                      <div className="font-semibold text-white text-sm md:text-base mb-1">Adres</div>
                      <div className="text-gray-300 text-sm md:text-base">Ternesselei 191<br />2160 Wommelgem</div>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-phone-line text-white text-lg md:text-xl"></i>
                    </div>
                    <div>
                      <div className="font-semibold text-white text-sm md:text-base mb-1">Telefoon</div>
                      <a href="tel:0489170592" className="text-cyan-400 hover:text-cyan-300 transition-colors text-sm md:text-base">
                        0489 17 05 92
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-time-line text-white text-lg md:text-xl"></i>
                    </div>
                    <div>
                      <div className="font-semibold text-white text-sm md:text-base mb-1">Openingstijden</div>
                      <div className="text-gray-300 text-sm md:text-base">
                        Ma-Vr: 08:00 - 18:00<br />
                        Za: 09:00 - 16:00<br />
                        Zo: Gesloten
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => window.REACT_APP_NAVIGATE('/contact-afspraak-antwerpen')}
                  className="mt-6 md:mt-8 w-full px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold text-sm md:text-base rounded-xl transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  <i className="ri-calendar-line text-lg md:text-xl"></i>
                  Maak een Afspraak
                </button>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 md:py-16 px-4 bg-gradient-to-b from-gray-900 to-black">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
              {[
                { number: '500+', label: 'Tevreden Klanten' },
                { number: '5+', label: 'Jaar Ervaring' },
                { number: '2', label: 'Jaar Garantie' },
                { number: '4.9', label: 'Google Reviews' }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 md:p-8"
                >
                  <div className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent mb-2">
                    {stat.number}
                  </div>
                  <div className="text-xs md:text-sm text-gray-300">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}

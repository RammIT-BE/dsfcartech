import { motion } from 'framer-motion';
import { useState } from 'react';
import Navigation from '../../components/feature/Navigation';
import Footer from '../../components/feature/Footer';
import SEOHead from '../../components/SEOHead';

export default function DienstenPage() {
  const [activeService, setActiveService] = useState(0);
  const siteUrl = import.meta.env.VITE_SITE_URL || 'https://dsfcartech.be';

  const services = [
    {
      id: 'carplay',
      icon: 'ri-smartphone-line',
      title: 'CarPlay & Android Auto',
      subtitle: 'Naadloze smartphone integratie',
      description: 'Upgrade uw auto met draadloze CarPlay en Android Auto. Geniet van naadloze smartphone integratie met uw dashboard voor navigatie, muziek, berichten en meer.',
      longDescription: 'Bij DSF Cartech in Antwerpen installeren wij professionele CarPlay en Android Auto systemen in vrijwel elk automerk. Of u nu een oudere auto heeft zonder moderne technologie, of een nieuwer model wilt upgraden naar draadloze connectiviteit - wij hebben de oplossing. Onze installaties zijn volledig geïntegreerd met uw bestaande dashboard en stuurwielknoppen, zodat alles veilig en gebruiksvriendelijk blijft tijdens het rijden.',
      benefits: [
        'Compatibel met iPhone en Android smartphones',
        'Draadloze verbinding zonder kabels',
        'Volledige integratie met stuurwielknoppen',
        'Behoud van originele radio functionaliteit',
        'Professionele installatie zonder schade',
        'Garantie op materiaal en installatie',
      ],
      useCases: [
        { title: 'Navigatie', desc: 'Google Maps, Waze en Apple Maps op groot scherm' },
        { title: 'Muziek', desc: 'Spotify, Apple Music, YouTube Music en meer' },
        { title: 'Berichten', desc: 'WhatsApp, SMS en iMessage via spraakbediening' },
        { title: 'Bellen', desc: 'Handsfree bellen met kristalheldere geluidskwaliteit' },
      ],
      image: 'https://static.readdy.ai/image/9e62058216dff63d1a686833c97014ce/95842c940ae17c4b913fe5fce8e14e37.jpeg',
      features: [
        { icon: 'ri-wifi-line', title: 'Draadloos verbinden', desc: 'Geen kabels meer nodig' },
        { icon: 'ri-mic-line', title: 'Voice control', desc: 'Handsfree bediening' },
        { icon: 'ri-navigation-line', title: 'Navigatie', desc: 'Google Maps & Apple Maps' },
        { icon: 'ri-music-line', title: 'Muziek streaming', desc: 'Spotify, Apple Music, etc.' },
      ],
      color: 'from-cyan-400 to-blue-500',
      glowColor: 'cyan',
    },
    {
      id: 'sterrenhemel',
      icon: 'ri-star-line',
      title: 'Sterrenhemel',
      subtitle: 'Luxe fiber optic plafond',
      description: 'Transformeer uw auto-interieur met een adembenemende sterrenhemel. Duizenden fiber optic lichtpunten creëren een magische sfeer met twinkle effect en dimbare verlichting.',
      longDescription: 'Een sterrenhemel in uw auto is de ultieme luxe upgrade die uw interieur transformeert tot een exclusieve ruimte. Bij DSF Cartech in Antwerpen installeren wij handmatig duizenden fiber optic vezels in uw hemelstof, waardoor een realistische sterrenhemel ontstaat. Elke installatie is uniek en volledig op maat gemaakt. Het twinkle effect zorgt voor knipperende sterren, net als een echte nachtelijke hemel. Perfect voor wie zijn auto wil onderscheiden met een premium uitstraling.',
      benefits: [
        'Handmatige installatie van 200-800 fiber optic punten',
        'Instelbare helderheid en twinkle snelheid',
        'Keuze uit verschillende kleuren (wit, blauw, RGB)',
        'Geen warmte ontwikkeling - veilig voor hemelstof',
        'Professionele afwerking zonder zichtbare bedrading',
        'Levenslange garantie op fiber optic vezels',
      ],
      useCases: [
        { title: 'Luxe uitstraling', desc: 'Premium sfeer voor speciale gelegenheden' },
        { title: 'Nachtritten', desc: 'Romantische en ontspannen sfeer tijdens avondritten' },
        { title: 'Showcar', desc: 'Eyecatcher op autoshows en evenementen' },
        { title: 'Uniek interieur', desc: 'Onderscheid uw auto van alle anderen' },
      ],
      image: 'https://static.readdy.ai/image/9e62058216dff63d1a686833c97014ce/b97434262329e812a17292bb4b7d2069.jpeg',
      features: [
        { icon: 'ri-star-fill', title: 'Duizenden lichtpunten', desc: 'Realistische sterrenhemel' },
        { icon: 'ri-flashlight-line', title: 'Twinkle effect', desc: 'Knipperende sterren' },
        { icon: 'ri-contrast-2-line', title: 'Dimbaar', desc: 'Instelbare helderheid' },
        { icon: 'ri-palette-line', title: 'Kleurkeuze', desc: 'Verschillende kleuren' },
      ],
      color: 'from-purple-400 to-pink-500',
      glowColor: 'purple',
    },
    {
      id: 'sfeerverlichting',
      icon: 'ri-lightbulb-line',
      title: 'Sfeerverlichting',
      subtitle: 'RGB LED ambient lighting',
      description: 'Creëer de perfecte sfeer met RGB LED strips voor interieur, deuren en voetenruimte. Miljoenen kleuren, app bediening en muziek synchronisatie voor een unieke rijervaring.',
      longDescription: 'RGB sfeerverlichting geeft uw auto-interieur een moderne en luxe uitstraling. Bij DSF Cartech in Antwerpen installeren wij hoogwaardige LED strips op strategische locaties: dashboard, deuren, voetenruimte, middenconsole en zelfs in de kofferbak. Via een gebruiksvriendelijke smartphone app kiest u uit miljoenen kleuren en effecten. De muziek synchronisatie functie laat de verlichting meebewegen op het ritme van uw favoriete muziek. Perfect voor wie zijn auto wil personaliseren met een unieke sfeer.',
      benefits: [
        'Miljoenen kleuren en effecten beschikbaar',
        'Smartphone app voor iOS en Android',
        'Muziek synchronisatie met microfoon',
        'Automatische timers en schema\'s',
        'Dimbare verlichting voor elke situatie',
        'Professionele installatie zonder zichtbare bedrading',
      ],
      useCases: [
        { title: 'Dagelijks gebruik', desc: 'Subtiele verlichting voor veilig rijden' },
        { title: 'Avondritten', desc: 'Sfeervolle kleuren voor ontspannen ritten' },
        { title: 'Feesten', desc: 'Muziek sync voor party sfeer in de auto' },
        { title: 'Showcar', desc: 'Opvallende effecten voor autoshows' },
      ],
      image: 'https://static.readdy.ai/image/9e62058216dff63d1a686833c97014ce/80a25d370de50e21e21aa8b290fa409c.jpeg',
      features: [
        { icon: 'ri-palette-line', title: 'Miljoenen kleuren', desc: 'RGB kleurenkeuze' },
        { icon: 'ri-smartphone-line', title: 'App bediening', desc: 'Controle via smartphone' },
        { icon: 'ri-music-2-line', title: 'Muziek sync', desc: 'Reageert op muziek' },
        { icon: 'ri-timer-line', title: 'Timers', desc: 'Automatische schema\'s' },
      ],
      color: 'from-pink-400 to-orange-500',
      glowColor: 'pink',
    },
    {
      id: 'camera',
      icon: 'ri-camera-line',
      title: 'Achteruitrijcamera',
      subtitle: 'HD camera met parkeerassistentie',
      description: 'Parkeer veilig en gemakkelijk met onze HD achteruitrijcamera\'s. Crystal clear beeld, nachtzicht functie, parkeerlijnen en optioneel 360° view voor complete overzicht.',
      longDescription: 'Veilig parkeren en manoeuvreren wordt een stuk eenvoudiger met een professionele achteruitrijcamera van DSF Cartech in Antwerpen. Wij installeren hoogwaardige HD camera\'s met kristalhelder beeld, zelfs bij slecht weer en in het donker dankzij de nachtzicht functie. De dynamische parkeerlijnen bewegen mee met uw stuurwiel, zodat u precies ziet waar uw auto naartoe gaat. Voor maximale veiligheid bieden wij ook 360° camera systemen aan, waarbij u een vogelperspectief van uw auto ziet met alle omliggende obstakels.',
      benefits: [
        'HD resolutie voor kristalhelder beeld',
        'Nachtzicht met infrarood LED\'s',
        'Dynamische parkeerlijnen gekoppeld aan stuurwiel',
        'Waterdichte camera\'s voor alle weersomstandigheden',
        'Integratie met bestaand scherm of nieuw display',
        'Optioneel 360° view met meerdere camera\'s',
      ],
      useCases: [
        { title: 'Parkeren', desc: 'Veilig inparkeren zonder schade' },
        { title: 'Achteruitrijden', desc: 'Overzicht van obstakels en personen' },
        { title: 'Aanhanger', desc: 'Gemakkelijk koppelen van aanhanger of caravan' },
        { title: 'Nauwe ruimtes', desc: 'Manoeuvreren in krappe parkeergarages' },
      ],
      image: 'https://static.readdy.ai/image/9e62058216dff63d1a686833c97014ce/3d64f136a9894c3e464cb63a8fd00377.jpeg',
      features: [
        { icon: 'ri-hd-line', title: 'Crystal clear beeld', desc: 'HD resolutie' },
        { icon: 'ri-moon-line', title: 'Nachtzicht', desc: 'Ook in het donker' },
        { icon: 'ri-guide-line', title: 'Parkeerlijnen', desc: 'Dynamische hulplijnen' },
        { icon: 'ri-360-line', title: '360° view', desc: 'Complete overzicht' },
      ],
      color: 'from-green-400 to-emerald-500',
      glowColor: 'green',
    },
    {
      id: 'android',
      icon: 'ri-tablet-line',
      title: 'Android Schermen',
      subtitle: 'Smart multimedia displays',
      description: 'Upgrade naar een modern Android scherm met 4G connectiviteit. Stream Netflix, YouTube, Spotify en meer. Volledige Google Play toegang voor entertainment en navigatie tijdens het rijden.',
      longDescription: 'Transformeer uw auto-interieur met een groot Android multimedia scherm van DSF Cartech in Antwerpen. Deze moderne displays vervangen uw oude radio en bieden toegang tot alle populaire apps zoals Netflix, YouTube, Spotify en Google Maps. Dankzij de ingebouwde 4G connectiviteit bent u altijd online, zelfs zonder uw smartphone. De schermen zijn verkrijgbaar in verschillende formaten (van 9 tot 12.3 inch) en worden volledig geïntegreerd in uw dashboard voor een factory-look. Perfect voor lange ritten, wachten in de auto, of gewoon voor dagelijks entertainment.',
      benefits: [
        'Groot touchscreen display (9-12.3 inch)',
        'Ingebouwde 4G/LTE voor internet zonder smartphone',
        'Volledige Google Play Store toegang',
        'Compatibel met CarPlay en Android Auto',
        'GPS navigatie met offline kaarten',
        'Bluetooth voor handsfree bellen en muziek',
      ],
      useCases: [
        { title: 'Entertainment', desc: 'Netflix, YouTube en streaming tijdens wachten' },
        { title: 'Navigatie', desc: 'Google Maps met real-time verkeersinformatie' },
        { title: 'Muziek', desc: 'Spotify, YouTube Music en alle streaming diensten' },
        { title: 'Productiviteit', desc: 'E-mail, agenda en zakelijke apps' },
      ],
      image: 'https://static.readdy.ai/image/9e62058216dff63d1a686833c97014ce/b238ac32bd71f42da2bcafc90577c0c1.jpeg',
      features: [
        { icon: 'ri-netflix-line', title: 'Streaming apps', desc: 'Netflix, YouTube, etc.' },
        { icon: 'ri-signal-tower-line', title: '4G connectiviteit', desc: 'Altijd online' },
        { icon: 'ri-google-play-line', title: 'Google Play', desc: 'Alle apps beschikbaar' },
        { icon: 'ri-layout-line', title: 'Groot scherm', desc: 'Tesla-style display' },
      ],
      color: 'from-blue-400 to-indigo-500',
      glowColor: 'blue',
    },
  ];

  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": "Auto Elektronica Upgrades - DSF Cartech",
    "description": "Professionele auto-upgrades: CarPlay, Android Auto, sterrenhemel, sfeerverlichting, camera's en Android schermen in Antwerpen.",
    "provider": {
      "@type": "LocalBusiness",
      "name": "DSF Cartech",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Ternesselei 191",
        "addressLocality": "Wommelgem",
        "addressRegion": "Antwerpen",
        "postalCode": "2160",
        "addressCountry": "BE"
      }
    },
    "areaServed": "Antwerpen",
    "serviceType": ["CarPlay installatie", "Android Auto", "Sterrenhemel", "Sfeerverlichting", "Achteruitrijcamera", "Android schermen"]
  };

  return (
    <>
      <SEOHead
        title="Diensten - Auto Upgrades Antwerpen | DSF Cartech"
        description="Ontdek onze professionele auto-upgrades: CarPlay, Android Auto, sterrenhemel, RGB sfeerverlichting, achteruitrijcamera's en Android schermen. Betrouwbare installatie in Antwerpen."
        keywords="auto upgrades antwerpen, carplay installatie, android auto, sterrenhemel auto, sfeerverlichting auto, achteruitrijcamera, android scherm auto, auto elektronica antwerpen"
        canonical={`${siteUrl}/diensten-auto-upgrades-antwerpen`}
        schema={schema}
      />

      <div className="bg-black text-white min-h-screen">
        <Navigation />

        {/* Hero Section */}
        <section className="relative pt-24 md:pt-32 pb-12 md:pb-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-cyan-950/20 via-black to-black"></div>
          
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-20 left-1/4 w-96 h-96 bg-cyan-500/30 rounded-full blur-3xl"></div>
            <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-blue-500/30 rounded-full blur-3xl"></div>
          </div>

          <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="inline-block mb-4 md:mb-6"
              >
                <div className="px-4 md:px-6 py-2 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-2 border-cyan-400/50 rounded-full backdrop-blur-sm">
                  <span className="text-cyan-300 text-xs md:text-sm font-bold tracking-widest uppercase">Onze Diensten</span>
                </div>
              </motion.div>

              <h1 className="text-3xl md:text-5xl lg:text-7xl font-bold mb-4 md:mb-6 leading-tight px-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                <span className="text-white">Professionele Auto</span>
                <br />
                <span className="bg-gradient-to-r from-cyan-300 via-blue-300 to-cyan-300 bg-clip-text text-transparent">
                  Upgrades
                </span>
              </h1>

              <p className="text-base md:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed px-4">
                Transformeer uw auto met onze professionele elektronica upgrades. Van CarPlay tot sterrenhemel, wij maken uw rijervaring uniek.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Services Navigation */}
        <section className="sticky top-16 md:top-20 z-40 bg-black/95 backdrop-blur-xl border-b border-white/10">
          <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
            <div className="flex overflow-x-auto gap-2 py-3 md:py-4 scrollbar-hide">
              {services.map((service, index) => (
                <motion.button
                  key={service.id}
                  onClick={() => {
                    setActiveService(index);
                    document.getElementById(service.id)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`flex items-center gap-2 px-4 md:px-6 py-2 md:py-3 rounded-xl whitespace-nowrap transition-all duration-300 cursor-pointer ${
                    activeService === index
                      ? `bg-gradient-to-r ${service.color} text-white shadow-lg`
                      : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <i className={`${service.icon} text-base md:text-lg`}></i>
                  <span className="font-semibold text-xs md:text-sm">{service.title}</span>
                </motion.button>
              ))}
            </div>
          </div>
        </section>

        {/* Services Details */}
        <section className="py-12 md:py-20">
          <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 space-y-20 md:space-y-32">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                id={service.id}
                initial={{ opacity: 0, y: 60 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true, margin: "-100px" }}
                className="relative"
              >
                {/* Background Glow */}
                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-5 blur-3xl rounded-3xl`}></div>

                <div className={`relative grid lg:grid-cols-2 gap-8 md:gap-12 items-center ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                  {/* Image */}
                  <motion.div
                    initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    viewport={{ once: true }}
                    className={`relative ${index % 2 === 1 ? 'lg:order-2' : ''}`}
                  >
                    <div className="relative group">
                      <div className={`absolute -inset-4 bg-gradient-to-br ${service.color} opacity-20 blur-2xl group-hover:opacity-30 transition-opacity duration-500 rounded-3xl`}></div>
                      <div className="relative overflow-hidden rounded-2xl border-2 border-white/10">
                        <img
                          src={service.image}
                          alt={service.title}
                          className="w-full h-64 md:h-96 object-cover transform group-hover:scale-105 transition-transform duration-700"
                        />
                      </div>
                    </div>
                  </motion.div>

                  {/* Content */}
                  <motion.div
                    initial={{ opacity: 0, x: index % 2 === 0 ? 40 : -40 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    viewport={{ once: true }}
                    className={index % 2 === 1 ? 'lg:order-1' : ''}
                  >
                    <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-6">
                      <div className={`w-12 h-12 md:w-16 md:h-16 flex items-center justify-center bg-gradient-to-br ${service.color} rounded-2xl shadow-2xl`}>
                        <i className={`${service.icon} text-2xl md:text-3xl text-white`}></i>
                      </div>
                      <div>
                        <h2 className="text-2xl md:text-4xl font-bold text-white" style={{ fontFamily: 'Orbitron, monospace' }}>
                          {service.title}
                        </h2>
                        <p className={`text-sm md:text-lg bg-gradient-to-r ${service.color} bg-clip-text text-transparent font-semibold`}>
                          {service.subtitle}
                        </p>
                      </div>
                    </div>

                    <p className="text-base md:text-lg text-gray-300 leading-relaxed mb-4 md:mb-6">
                      {service.description}
                    </p>

                    <p className="text-sm md:text-base text-gray-400 leading-relaxed mb-6 md:mb-8">
                      {service.longDescription}
                    </p>

                    {/* Features Grid */}
                    <div className="grid grid-cols-2 gap-3 md:gap-4 mb-6 md:mb-8">
                      {service.features.map((feature, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, y: 20 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: 0.4 + idx * 0.1 }}
                          viewport={{ once: true }}
                          className="p-3 md:p-4 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 hover:bg-white/10 transition-all duration-300"
                        >
                          <i className={`${feature.icon} text-xl md:text-2xl bg-gradient-to-r ${service.color} bg-clip-text text-transparent mb-2`}></i>
                          <h4 className="text-white font-semibold text-xs md:text-sm mb-1">{feature.title}</h4>
                          <p className="text-gray-400 text-xs">{feature.desc}</p>
                        </motion.div>
                      ))}
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => window.REACT_APP_NAVIGATE('/contact-afspraak-antwerpen')}
                      className={`w-full md:w-auto px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r ${service.color} text-white font-bold rounded-xl whitespace-nowrap cursor-pointer shadow-2xl hover:shadow-3xl transition-all duration-300`}
                    >
                      <span className="flex items-center justify-center gap-2">
                        <i className="ri-calendar-check-line text-lg md:text-xl"></i>
                        <span className="text-sm md:text-base">Maak een Afspraak</span>
                      </span>
                    </motion.button>
                  </motion.div>
                </div>

                {/* Extended Content Section */}
                <motion.div
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                  viewport={{ once: true }}
                  className="mt-12 md:mt-16 grid md:grid-cols-2 gap-6 md:gap-8"
                >
                  {/* Benefits */}
                  <div className="p-6 md:p-8 bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10">
                    <h3 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6 flex items-center gap-3">
                      <i className="ri-checkbox-circle-line text-2xl md:text-3xl bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent"></i>
                      <span>Voordelen</span>
                    </h3>
                    <ul className="space-y-3 md:space-y-4">
                      {service.benefits.map((benefit, idx) => (
                        <motion.li
                          key={idx}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.5, delay: idx * 0.1 }}
                          viewport={{ once: true }}
                          className="flex items-start gap-3 text-gray-300"
                        >
                          <i className={`ri-check-line text-lg md:text-xl bg-gradient-to-r ${service.color} bg-clip-text text-transparent mt-1 flex-shrink-0`}></i>
                          <span className="text-xs md:text-sm leading-relaxed">{benefit}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </div>

                  {/* Use Cases */}
                  <div className="p-6 md:p-8 bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10">
                    <h3 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6 flex items-center gap-3">
                      <i className="ri-lightbulb-line text-2xl md:text-3xl bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent"></i>
                      <span>Toepassingen</span>
                    </h3>
                    <div className="space-y-3 md:space-y-4">
                      {service.useCases.map((useCase, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, x: 20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.5, delay: idx * 0.1 }}
                          viewport={{ once: true }}
                          className="p-3 md:p-4 bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-all duration-300"
                        >
                          <h4 className={`text-white font-semibold text-xs md:text-sm mb-1 bg-gradient-to-r ${service.color} bg-clip-text text-transparent`}>
                            {useCase.title}
                          </h4>
                          <p className="text-gray-400 text-xs leading-relaxed">{useCase.desc}</p>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative py-20 md:py-32 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-black via-cyan-950/20 to-black"></div>
          
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/40 rounded-full blur-3xl"></div>
          </div>

          <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 relative z-10 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6 text-white" style={{ fontFamily: 'Orbitron, monospace' }}>
                Klaar voor een <span className="bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent">Upgrade?</span>
              </h2>
              <p className="text-base md:text-xl text-gray-300 mb-8 md:mb-12 leading-relaxed px-4">
                Neem contact op voor een vrijblijvend adviesgesprek en ontdek wat wij voor uw auto kunnen betekenen.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center px-4">
                <motion.button
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => window.REACT_APP_NAVIGATE('/contact-afspraak-antwerpen')}
                  className="w-full sm:w-auto px-8 md:px-12 py-4 md:py-5 bg-gradient-to-r from-cyan-500 to-blue-500 text-black text-base md:text-lg font-bold rounded-2xl whitespace-nowrap cursor-pointer shadow-2xl shadow-cyan-500/50 hover:shadow-cyan-500/70 transition-all duration-300"
                >
                  <span className="flex items-center justify-center gap-3">
                    <i className="ri-calendar-check-line text-xl md:text-2xl"></i>
                    <span>Maak een Afspraak</span>
                  </span>
                </motion.button>

                <motion.a
                  href="tel:+32489170592"
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full sm:w-auto px-8 md:px-12 py-4 md:py-5 bg-white/10 backdrop-blur-xl border-2 border-white/30 text-white text-base md:text-lg font-bold rounded-2xl whitespace-nowrap cursor-pointer hover:bg-white/20 transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  <span className="flex items-center justify-center gap-3">
                    <i className="ri-phone-line text-xl md:text-2xl"></i>
                    <span>Bel Direct</span>
                  </span>
                </motion.a>
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}

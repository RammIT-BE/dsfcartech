import { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import Navigation from '../../components/feature/Navigation';
import Footer from '../../components/feature/Footer';
import SEOHead from '../../components/SEOHead';
import HeroSection from './components/HeroSection';
import CarPlaySection from './components/CarPlaySection';
import StarRoofSection from './components/StarRoofSection';
import AmbientLightingSection from './components/AmbientLightingSection';
import BackupCameraSection from './components/BackupCameraSection';
import OverviewSection from './components/OverviewSection';

export default function HomePage() {
  const siteUrl = import.meta.env.VITE_SITE_URL || 'https://dsfcartech.be';

  const schema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "DSF Cartech",
    "description": "DSF Cartech is actief in regio Antwerpen en specialiseert zich in professionele auto-upgrades zoals CarPlay, Android Auto, camera's en interieurverlichting.",
    "url": siteUrl,
    "telephone": "+32489170592",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Ternesselei 191",
      "addressLocality": "Wommelgem",
      "addressRegion": "Antwerpen",
      "postalCode": "2160",
      "addressCountry": "BE"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": "51.2194",
      "longitude": "4.4025"
    },
    "openingHoursSpecification": [
      {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        "opens": "08:00",
        "closes": "18:00"
      },
      {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": "Saturday",
        "opens": "09:00",
        "closes": "16:00"
      }
    ],
    "priceRange": "€€",
    "image": `${siteUrl}/og-image.jpg`,
    "sameAs": [
      "https://www.facebook.com/dsfcartech",
      "https://www.instagram.com/dsfcartech"
    ]
  };

  return (
    <>
      <SEOHead
        title="DSF Cartech | CarPlay, Sfeerverlichting Antwerpen"
        description="DSF Cartech is actief in regio Antwerpen en specialiseert zich in professionele auto-upgrades zoals CarPlay, Android Auto, camera's en interieurverlichting. Betrouwbare service, hoogwaardige materialen en maatwerkoplossingen."
        keywords="android schermen antwerpen, android auto scherm, tesla scherm auto, android display auto, netflix in auto, youtube auto scherm, spotify auto display, google play auto, 4g scherm auto, streaming auto antwerpen, android multimedia antwerpen"
        canonical={`${siteUrl}/`}
        schema={schema}
      />
      
      <div className="bg-black text-white overflow-x-hidden">
        <Navigation />
        
        {/* Hero Section */}
        <HeroSection />
        
        {/* CarPlay Section */}
        <CarPlaySection />
        
        {/* Star Roof Section */}
        <StarRoofSection />
        
        {/* Ambient Lighting Section */}
        <AmbientLightingSection />
        
        {/* Backup Camera Section */}
        <BackupCameraSection />
        
        {/* Overview Section */}
        <OverviewSection />
        
        <Footer />
      </div>
    </>
  );
}

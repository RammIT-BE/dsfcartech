import { motion, MotionValue } from 'framer-motion';

interface ScrollIndicatorProps {
  progress: MotionValue<number>;
  currentSection: number;
  totalSections: number;
}

export default function ScrollIndicator({ progress, currentSection, totalSections }: ScrollIndicatorProps) {
  const sections = [
    { name: 'Start', icon: 'ri-home-line' },
    { name: 'CarPlay', icon: 'ri-smartphone-line' },
    { name: 'Sterren', icon: 'ri-star-line' },
    { name: 'LED', icon: 'ri-lightbulb-line' },
    { name: 'Camera', icon: 'ri-camera-line' },
    { name: 'Overzicht', icon: 'ri-eye-line' }
  ];

  return (
    <div className="fixed right-8 top-1/2 transform -translate-y-1/2 z-50 hidden lg:block">
      {/* Progress Bar */}
      <div className="w-1 h-64 bg-white/20 rounded-full overflow-hidden mb-8">
        <motion.div
          className="w-full bg-gradient-to-t from-cyan-400 to-blue-500 rounded-full origin-top"
          style={{ scaleY: progress }}
        />
      </div>

      {/* Section Indicators */}
      <div className="space-y-4">
        {sections.map((section, index) => (
          <motion.div
            key={index}
            className={`flex items-center space-x-3 cursor-pointer group ${
              currentSection === index ? 'opacity-100' : 'opacity-50 hover:opacity-75'
            }`}
            onClick={() => {
              const element = document.querySelector(`section:nth-of-type(${index + 1})`);
              element?.scrollIntoView({ behavior: 'smooth' });
            }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className={`w-3 h-3 rounded-full transition-all duration-300 ${
              currentSection === index 
                ? 'bg-gradient-to-r from-cyan-400 to-blue-500 scale-125' 
                : 'bg-white/40 group-hover:bg-white/60'
            }`} />
            
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ 
                opacity: currentSection === index ? 1 : 0,
                x: currentSection === index ? 0 : 10
              }}
              className="bg-black/80 backdrop-blur-sm px-3 py-1 rounded-lg border border-white/20"
            >
              <div className="flex items-center space-x-2">
                <i className={`${section.icon} text-cyan-400 text-sm`}></i>
                <span className="text-white text-sm font-medium whitespace-nowrap">
                  {section.name}
                </span>
              </div>
            </motion.div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
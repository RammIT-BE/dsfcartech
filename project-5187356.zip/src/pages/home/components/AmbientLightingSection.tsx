import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef, useState } from 'react';

export default function AmbientLightingSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start']
  });

  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);
  const [selectedColor, setSelectedColor] = useState('#00ffff');

  const colors = [
    { name: 'Cyaan', value: '#00ffff' },
    { name: 'Paars', value: '#9333ea' },
    { name: 'Roze', value: '#ec4899' },
    { name: 'Groen', value: '#10b981' },
    { name: 'Oranje', value: '#f97316' },
    { name: 'Rood', value: '#ef4444' },
  ];

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center py-16 md:py-32 bg-black">
      <motion.div 
        style={{ opacity }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full"
      >
        <div className="grid lg:grid-cols-2 gap-10 md:gap-20 items-center">
          {/* Left - LED Demo */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative order-2 lg:order-1"
          >
            <div className="relative aspect-[4/3] bg-black rounded-2xl md:rounded-3xl overflow-hidden border-2 md:border-4 border-pink-500/30 shadow-2xl shadow-pink-500/20">
              {/* Car Interior Mockup */}
              <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-black p-4 md:p-8">
                {/* Door Panels */}
                <motion.div
                  animate={{ boxShadow: `0 0 30px ${selectedColor}` }}
                  className="absolute left-4 md:left-8 top-1/4 w-1 md:w-2 h-20 md:h-32 rounded-full"
                  style={{ backgroundColor: selectedColor }}
                />
                <motion.div
                  animate={{ boxShadow: `0 0 30px ${selectedColor}` }}
                  className="absolute right-4 md:right-8 top-1/4 w-1 md:w-2 h-20 md:h-32 rounded-full"
                  style={{ backgroundColor: selectedColor }}
                />
                
                {/* Footwell */}
                <motion.div
                  animate={{ boxShadow: `0 0 40px ${selectedColor}` }}
                  className="absolute bottom-4 md:bottom-8 left-1/4 w-20 md:w-32 h-1 md:h-2 rounded-full"
                  style={{ backgroundColor: selectedColor }}
                />
                <motion.div
                  animate={{ boxShadow: `0 0 40px ${selectedColor}` }}
                  className="absolute bottom-4 md:bottom-8 right-1/4 w-20 md:w-32 h-1 md:h-2 rounded-full"
                  style={{ backgroundColor: selectedColor }}
                />

                {/* Dashboard */}
                <motion.div
                  animate={{ boxShadow: `0 0 30px ${selectedColor}` }}
                  className="absolute top-4 md:top-8 left-1/2 -translate-x-1/2 w-32 md:w-48 h-1 md:h-2 rounded-full"
                  style={{ backgroundColor: selectedColor }}
                />
              </div>

              {/* Color Selector */}
              <div className="absolute bottom-4 md:bottom-8 left-1/2 -translate-x-1/2 flex gap-2 md:gap-4 bg-black/50 backdrop-blur-md p-2 md:p-4 rounded-full border border-white/10">
                {colors.map((color) => (
                  <motion.button
                    key={color.value}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setSelectedColor(color.value)}
                    className="w-8 h-8 md:w-12 md:h-12 rounded-full border-2 cursor-pointer"
                    style={{
                      backgroundColor: color.value,
                      borderColor: selectedColor === color.value ? 'white' : 'transparent',
                    }}
                    title={color.name}
                  />
                ))}
              </div>
            </div>

            {/* Glow Effect */}
            <motion.div
              animate={{ backgroundColor: `${selectedColor}33` }}
              className="absolute inset-0 blur-3xl -z-10"
            />
          </motion.div>

          {/* Right Content */}
          <div className="space-y-6 md:space-y-10 order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-8" style={{ fontFamily: 'Orbitron, monospace' }}>
                <span className="bg-gradient-to-r from-pink-400 to-orange-500 bg-clip-text text-transparent">
                  Sfeerverlichting
                </span>
              </h2>
              <p className="text-base sm:text-lg md:text-xl text-gray-400 leading-relaxed mb-6 md:mb-10">
                Creëer de perfecte sfeer met LED verlichting voor interieur, 
                deurpanelen, voetenruimte en koffer. Volledig aanpasbaar aan uw wensen.
              </p>
            </motion.div>

            {/* Features */}
            <div className="space-y-4 md:space-y-8">
              {[
                { icon: 'ri-lightbulb-line', title: 'RGB LED Strips', desc: 'Miljoenen kleuren beschikbaar' },
                { icon: 'ri-remote-control-line', title: 'App Bediening', desc: 'Bedien via smartphone of dashboard' },
                { icon: 'ri-music-2-line', title: 'Muziek Sync', desc: 'Lichtshow op het ritme van muziek' },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="flex items-start gap-3 md:gap-6"
                >
                  <div className="w-12 h-12 md:w-16 md:h-16 flex items-center justify-center bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-lg md:rounded-xl border border-pink-500/30 flex-shrink-0">
                    <i className={`${feature.icon} text-2xl md:text-3xl text-pink-400`}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg md:text-xl font-semibold text-white mb-1 md:mb-3">{feature.title}</h3>
                    <p className="text-gray-400 text-sm md:text-lg">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.REACT_APP_NAVIGATE('/diensten-auto-upgrades-antwerpen')}
              className="mt-6 md:mt-12 w-full sm:w-auto px-6 md:px-10 py-4 md:py-5 bg-gradient-to-r from-pink-500 to-orange-500 text-white font-semibold rounded-xl text-base md:text-lg whitespace-nowrap cursor-pointer shadow-lg hover:shadow-pink-500/30 transition-all duration-300"
            >
              Ontdek Mogelijkheden
            </motion.button>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
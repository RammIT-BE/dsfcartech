import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef, useState } from 'react';

export default function StarRoofSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start']
  });

  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);
  const [starsVisible, setStarsVisible] = useState(true);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center py-32 bg-black">
      <motion.div 
        style={{ opacity }}
        className="max-w-7xl mx-auto px-6 lg:px-8"
      >
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          {/* Left - Star Roof Demo */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative order-2 lg:order-1"
          >
            <div className="relative aspect-[4/3] bg-black rounded-3xl overflow-hidden border-4 border-purple-500/30 shadow-2xl shadow-purple-500/20">
              {/* Star Field */}
              <div className="absolute inset-0 bg-gradient-to-b from-black via-purple-950/20 to-black">
                {starsVisible && [...Array(100)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-white rounded-full"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                    }}
                    animate={{
                      opacity: [0.2, 1, 0.2],
                      scale: [1, 1.5, 1],
                    }}
                    transition={{
                      duration: 2 + Math.random() * 3,
                      repeat: Infinity,
                      delay: Math.random() * 2,
                    }}
                  />
                ))}
              </div>

              {/* Control Button */}
              <button
                onClick={() => setStarsVisible(!starsVisible)}
                className="absolute bottom-8 left-1/2 -translate-x-1/2 px-8 py-4 bg-white/10 backdrop-blur-md border-2 border-white/30 rounded-xl text-white font-semibold whitespace-nowrap cursor-pointer hover:bg-white/20 hover:border-white/50 transition-all duration-300 hover:scale-105"
              >
                {starsVisible ? 'Sterren Uit' : 'Sterren Aan'}
              </button>
            </div>

            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 blur-3xl -z-10"></div>
          </motion.div>

          {/* Right Content */}
          <div className="space-y-10 order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-5xl md:text-6xl font-bold mb-8" style={{ fontFamily: 'Orbitron, monospace' }}>
                <span className="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                  Sterrenhemel
                </span>
                <span className="text-white"> Installatie</span>
              </h2>
              <p className="text-xl text-gray-400 leading-relaxed mb-10">
                Transformeer uw auto-interieur met een adembenemende sterrenhemel. 
                Duizenden fiber optic lichtjes creëren een magische sfeer.
              </p>
            </motion.div>

            {/* Features */}
            <div className="space-y-8">
              {[
                { icon: 'ri-star-line', title: 'Fiber Optic Technologie', desc: 'Duizenden individuele lichtpunten' },
                { icon: 'ri-palette-line', title: 'Kleur Aanpasbaar', desc: 'Kies uw favoriete kleur of laat wisselen' },
                { icon: 'ri-flashlight-line', title: 'Dimbaar & Regelbaar', desc: 'Volledige controle over helderheid' },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="flex items-start gap-6"
                >
                  <div className="w-16 h-16 flex items-center justify-center bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl border border-purple-500/30">
                    <i className={`${feature.icon} text-3xl text-purple-400`}></i>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                    <p className="text-gray-400 text-lg">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.REACT_APP_NAVIGATE('/diensten-auto-upgrades-antwerpen')}
              className="mt-12 px-10 py-5 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold rounded-xl text-lg whitespace-nowrap cursor-pointer shadow-lg hover:shadow-purple-500/30 transition-all duration-300"
            >
              Bekijk Voorbeelden
            </motion.button>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
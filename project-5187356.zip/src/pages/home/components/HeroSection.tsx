
import { motion } from 'framer-motion';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black pt-24">
      {/* Optimized Starfield Background - Reduced stars */}
      <div className="absolute inset-0">
        {/* Main stars - reduced from 150 to 50 */}
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.3, 0.8, 0.3],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 4 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 3,
              ease: "easeInOut",
            }}
          />
        ))}
        
        {/* Larger accent stars - reduced from 20 to 8 */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={`accent-${i}`}
            className="absolute w-2 h-2 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: `radial-gradient(circle, ${
                i % 3 === 0 ? '#3b82f6' : i % 3 === 1 ? '#06b6d4' : '#0ea5e9'
              }, transparent)`,
            }}
            animate={{
              opacity: [0.2, 0.6, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 5 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 4,
              ease: "easeInOut",
            }}
          />
        ))}

        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/20 via-transparent to-black/50"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-900/10 via-transparent to-blue-900/10"></div>
      </div>

      {/* Scroll Indicator - Right Side (alleen desktop) */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 1, delay: 1.5 }}
        className="hidden lg:flex absolute right-8 top-1/2 -translate-y-1/2 z-20 flex-col items-center gap-4"
      >
        <motion.div
          animate={{ y: [0, 15, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center gap-3"
        >
          <div className="w-px h-20 bg-gradient-to-b from-transparent via-cyan-400 to-blue-500"></div>
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/50">
            <i className="ri-arrow-down-line text-white text-xl"></i>
          </div>
          <div className="w-px h-20 bg-gradient-to-b from-blue-500 via-cyan-400 to-transparent"></div>
        </motion.div>
        
        <div className="writing-mode-vertical text-gray-400 text-sm font-semibold tracking-wider" style={{ writingMode: 'vertical-rl' }}>
          SCROLL
        </div>
      </motion.div>

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 text-center">
        {/* Main Title */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-bold mb-4 sm:mb-6 leading-tight"
        >
          <span className="bg-gradient-to-r from-white via-blue-200 to-white bg-clip-text text-transparent">
            Transformeer Je Auto
          </span>
          <br />
          <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-sky-400 bg-clip-text text-transparent">
            In 1 Dag
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-base sm:text-xl md:text-2xl text-gray-300 mb-3 sm:mb-4 max-w-3xl mx-auto px-4"
        >
          CarPlay • Sterrenhemel • Sfeerverlichting • Camera's
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-sm sm:text-base md:text-lg text-gray-400 mb-8 sm:mb-12 px-4"
        >
          Professionele installatie met 2 jaar garantie
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mb-12 sm:mb-16 px-4"
        >
          <button
            onClick={() => window.REACT_APP_NAVIGATE('/contact-afspraak-antwerpen')}
            className="group relative px-6 sm:px-8 py-3 sm:py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-bold text-base sm:text-lg rounded-xl overflow-hidden whitespace-nowrap cursor-pointer shadow-lg hover:shadow-cyan-500/30 transition-all duration-300 hover:scale-105"
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              <i className="ri-calendar-line text-lg sm:text-xl"></i>
              <span className="hidden sm:inline">Gratis Offerte Aanvragen</span>
              <span className="sm:hidden">Gratis Offerte</span>
            </span>
          </button>
          
          <a
            href="tel:0489170592"
            className="group px-6 sm:px-8 py-3 sm:py-4 bg-white/10 backdrop-blur-sm border-2 border-white/30 text-white font-semibold text-base sm:text-lg rounded-xl hover:bg-white/20 hover:border-white/50 transition-all duration-300 flex items-center justify-center space-x-2 sm:space-x-3 whitespace-nowrap hover:scale-105"
          >
            <i className="ri-phone-line text-xl sm:text-2xl"></i>
            <span>0489 17 05 92</span>
          </a>
        </motion.div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-8 px-4"
        >
          {/* Google Reviews */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center">
              {[1, 2, 3, 4].map((star) => (
                <i key={star} className="ri-star-fill text-yellow-400 text-lg sm:text-xl"></i>
              ))}
              <i className="ri-star-half-fill text-yellow-400 text-lg sm:text-xl"></i>
            </div>
            <div className="text-left">
              <div className="font-bold text-white text-sm sm:text-base">4.9 Sterren</div>
              <div className="text-xs sm:text-sm text-gray-300">41 Google Reviews</div>
            </div>
          </div>

          {/* Installatie in 1 Dag */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center">
              <i className="ri-flashlight-fill text-white text-xl sm:text-2xl"></i>
            </div>
            <div className="text-left">
              <div className="font-bold text-white text-sm sm:text-base">Installatie in 1 Dag</div>
              <div className="text-xs sm:text-sm text-gray-300">Snel & Professioneel</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

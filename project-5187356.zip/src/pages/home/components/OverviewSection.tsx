import { motion } from 'framer-motion';
import { useState } from 'react';

export default function OverviewSection() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const services = [
    {
      icon: 'ri-smartphone-line',
      title: 'CarPlay & Android Auto',
      description: 'Naadloze smartphone integratie met je dashboard',
      features: ['Draadloos verbinden', 'Voice control', 'Navigatie & muziek'],
      color: 'from-cyan-400 to-blue-500',
      borderColor: 'border-cyan-500/20',
      glowColor: 'cyan',
      link: '/diensten-auto-upgrades-antwerpen',
    },
    {
      icon: 'ri-star-line',
      title: 'Sterrenhemel',
      description: 'Luxe fiber optic sterrendak voor ultieme sfeer',
      features: ['Duizenden lichtpunten', 'Twinkle effect', 'Dimbaar'],
      color: 'from-purple-400 to-pink-500',
      borderColor: 'border-purple-500/20',
      glowColor: 'purple',
      link: '/diensten-auto-upgrades-antwerpen',
    },
    {
      icon: 'ri-lightbulb-line',
      title: 'Sfeerverlichting',
      description: 'RGB LED strips voor interieur, deuren en voetenruimte',
      features: ['Miljoenen kleuren', 'App bediening', 'Muziek sync'],
      color: 'from-pink-400 to-orange-500',
      borderColor: 'border-pink-500/20',
      glowColor: 'pink',
      link: '/diensten-auto-upgrades-antwerpen',
    },
    {
      icon: 'ri-camera-line',
      title: 'Achteruitcamera',
      description: 'HD camera met parkeerlijnen en 360° view',
      features: ['Crystal clear beeld', 'Nachtzicht', 'Parkeer assist'],
      color: 'from-green-400 to-emerald-500',
      borderColor: 'border-green-500/20',
      glowColor: 'green',
      link: '/diensten-auto-upgrades-antwerpen',
    },
  ];

  return (
    <section className="relative bg-gradient-to-b from-black via-gray-950 to-black py-16 sm:py-24 lg:py-32 overflow-hidden">
      {/* Premium Background Elements */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>
      </div>

      {/* Subtle Grid Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Premium Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          viewport={{ once: true }}
          className="text-center mb-12 sm:mb-16 lg:mb-24"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="inline-block mb-6 sm:mb-8"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/30 to-blue-400/30 blur-2xl"></div>
              <div className="relative px-6 sm:px-8 py-2 sm:py-3 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-2 border-cyan-400/50 rounded-full backdrop-blur-sm">
                <span className="text-cyan-300 text-xs sm:text-sm font-bold tracking-[0.2em] sm:tracking-[0.3em] uppercase drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]">Premium Upgrades</span>
              </div>
            </div>
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-8xl font-bold mb-6 sm:mb-8 leading-tight drop-shadow-2xl" 
            style={{ fontFamily: 'Orbitron, monospace' }}
          >
            <span className="text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.3)]">
              Klaar voor een
            </span>
            <br />
            <span className="bg-gradient-to-r from-cyan-300 via-blue-300 to-cyan-300 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(34,211,238,0.6)]">
              Upgrade?
            </span>
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
            className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-200 max-w-3xl mx-auto leading-relaxed font-light drop-shadow-lg px-4"
          >
            Transformeer uw auto met onze professionele elektronica upgrades
          </motion.p>
        </motion.div>

        {/* Premium Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-16 sm:mb-24 lg:mb-32">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 60 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: index * 0.15, ease: "easeOut" }}
              viewport={{ once: true }}
              onHoverStart={() => setHoveredIndex(index)}
              onHoverEnd={() => setHoveredIndex(null)}
              className="relative group cursor-pointer"
            >
              {/* Premium Glow Effect */}
              <motion.div
                animate={{
                  opacity: hoveredIndex === index ? 0.6 : 0,
                  scale: hoveredIndex === index ? 1.1 : 1,
                }}
                transition={{ duration: 0.4 }}
                className={`absolute -inset-2 bg-gradient-to-br ${service.color} blur-3xl rounded-3xl`}
              />

              {/* Premium Card */}
              <motion.div
                animate={{
                  y: hoveredIndex === index ? -12 : 0,
                }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                className="relative h-full"
                onClick={() => window.REACT_APP_NAVIGATE(service.link)}
              >
                <div className={`relative p-6 sm:p-8 lg:p-10 bg-gradient-to-br from-gray-800/95 via-gray-900/95 to-black/95 backdrop-blur-xl rounded-3xl border-2 ${service.borderColor} h-full overflow-hidden shadow-2xl`}>
                  {/* Shine Effect */}
                  <motion.div
                    animate={{
                      opacity: hoveredIndex === index ? 0.1 : 0,
                      x: hoveredIndex === index ? '100%' : '-100%',
                    }}
                    transition={{ duration: 0.6 }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent skew-x-12"
                  />

                  {/* Icon Container */}
                  <motion.div
                    animate={{
                      scale: hoveredIndex === index ? 1.15 : 1,
                      rotate: hoveredIndex === index ? 5 : 0,
                    }}
                    transition={{ duration: 0.4 }}
                    className="relative mb-6 sm:mb-8"
                  >
                    <div className={`w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center bg-gradient-to-br ${service.color} rounded-2xl shadow-2xl`}>
                      <i className={`${service.icon} text-3xl sm:text-4xl text-white drop-shadow-lg`}></i>
                    </div>
                  </motion.div>

                  {/* Content */}
                  <h3 className="text-xl sm:text-2xl font-bold text-white mb-3 sm:mb-4 leading-tight drop-shadow-lg">{service.title}</h3>
                  <p className="text-gray-300 text-sm sm:text-base mb-4 sm:mb-6 leading-relaxed font-light">
                    {service.description}
                  </p>

                  {/* Features List */}
                  <div className="space-y-2 sm:space-y-3">
                    {service.features.map((feature, idx) => (
                      <motion.div 
                        key={idx} 
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: 0.6 + idx * 0.1 }}
                        viewport={{ once: true }}
                        className="flex items-center gap-2 sm:gap-3"
                      >
                        <div className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-gradient-to-r ${service.color} shadow-lg`} />
                        <span className="text-xs sm:text-sm text-gray-200 font-light">{feature}</span>
                      </motion.div>
                    ))}
                  </div>

                  {/* Arrow Indicator */}
                  <motion.div
                    animate={{
                      x: hoveredIndex === index ? 8 : 0,
                      opacity: hoveredIndex === index ? 1 : 0.4,
                    }}
                    transition={{ duration: 0.3 }}
                    className="absolute bottom-6 sm:bottom-8 right-6 sm:right-8"
                  >
                    <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white/10 flex items-center justify-center">
                      <i className="ri-arrow-right-line text-xl sm:text-2xl text-gray-200"></i>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Premium CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16 sm:mb-24 lg:mb-32"
        >
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center items-center mb-12 sm:mb-16 px-4">
            <motion.button
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.2 }}
              onClick={() => window.REACT_APP_NAVIGATE('/contact-afspraak-antwerpen')}
              className="relative group w-full sm:w-auto px-10 sm:px-14 py-4 sm:py-6 bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-500 text-black text-base sm:text-lg font-bold rounded-2xl whitespace-nowrap cursor-pointer overflow-hidden shadow-2xl shadow-cyan-500/50 hover:shadow-cyan-500/70"
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-600 via-cyan-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
              />
              <span className="relative z-10 flex items-center justify-center gap-2 sm:gap-3 drop-shadow-lg">
                <i className="ri-calendar-check-line text-xl sm:text-2xl"></i>
                <span className="hidden sm:inline">Maak een Afspraak</span>
                <span className="sm:hidden">Afspraak Maken</span>
              </span>
              {/* Shine Effect */}
              <motion.div
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12"
              />
            </motion.button>
            
            <motion.a
              href="/realisaties-auto-upgrades-antwerpen"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
              transition={{ duration: 0.2 }}
              className="w-full sm:w-auto px-10 sm:px-14 py-4 sm:py-6 bg-white/10 backdrop-blur-xl border-2 border-white/30 text-white text-base sm:text-lg font-bold rounded-2xl whitespace-nowrap cursor-pointer hover:bg-white/20 hover:border-white/50 transition-all duration-300 shadow-2xl hover:shadow-3xl"
            >
              <span className="flex items-center justify-center gap-2 sm:gap-3 drop-shadow-lg">
                <i className="ri-gallery-line text-xl sm:text-2xl"></i>
                <span className="hidden sm:inline">Bekijk Realisaties</span>
                <span className="sm:hidden">Realisaties</span>
              </span>
            </motion.a>
          </div>

          {/* Premium Contact Info */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
            className="flex flex-col sm:flex-row flex-wrap justify-center gap-6 sm:gap-8 lg:gap-12 px-4"
          >
            {[
              { icon: 'ri-phone-line', text: '0489 17 05 92', color: 'cyan', href: 'tel:0489170592' },
              { icon: 'ri-mail-line', text: 'info@dsfcartech.be', color: 'blue', href: 'mailto:info@dsfcartech.be' },
              { icon: 'ri-map-pin-line', text: 'Antwerpen, België', color: 'sky', href: '#' },
            ].map((contact, index) => (
              <motion.a
                key={index}
                href={contact.href}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -4 }}
                className="flex items-center gap-3 sm:gap-4 cursor-pointer group"
              >
                <div className={`w-12 h-12 sm:w-14 sm:h-14 flex items-center justify-center bg-gradient-to-br from-${contact.color}-400/20 to-${contact.color}-500/20 rounded-xl border-2 border-${contact.color}-400/40 group-hover:border-${contact.color}-400/60 transition-all duration-300 shadow-xl shadow-${contact.color}-500/20`}>
                  <i className={`${contact.icon} text-lg sm:text-xl text-${contact.color}-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.4)]`}></i>
                </div>
                <span className="text-sm sm:text-base font-medium text-gray-200 group-hover:text-white transition-colors duration-300 drop-shadow-md">{contact.text}</span>
              </motion.a>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
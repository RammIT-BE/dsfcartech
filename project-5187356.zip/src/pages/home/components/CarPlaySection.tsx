import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

export default function CarPlaySection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section ref={ref} className="min-h-screen bg-black flex items-center justify-center py-32 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ delay: 0.2 }}
                className="inline-block"
              >
                <span className="text-cyan-400 text-sm font-semibold tracking-wider uppercase">
                  Dashboard Upgrade
                </span>
              </motion.div>
              
              <h2 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
                CarPlay & <br />Android Auto
              </h2>
              
              <p className="text-gray-400 text-lg leading-relaxed">
                Integreer naadloos uw smartphone met het infotainmentsysteem van uw auto. 
                Toegang tot navigatie, muziek, berichten en meer via het dashboard.
              </p>
            </div>

            {/* Features */}
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 flex items-center justify-center bg-cyan-400/10 rounded-lg flex-shrink-0">
                  <i className="ri-smartphone-line text-2xl text-cyan-400"></i>
                </div>
                <div>
                  <h3 className="text-white font-semibold text-lg mb-2">Draadloze Connectiviteit</h3>
                  <p className="text-gray-400 text-sm">Automatische verbinding zonder kabels</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 flex items-center justify-center bg-cyan-400/10 rounded-lg flex-shrink-0">
                  <i className="ri-navigation-line text-2xl text-cyan-400"></i>
                </div>
                <div>
                  <h3 className="text-white font-semibold text-lg mb-2">Navigatie & Maps</h3>
                  <p className="text-gray-400 text-sm">Apple Maps, Google Maps en Waze</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 flex items-center justify-center bg-cyan-400/10 rounded-lg flex-shrink-0">
                  <i className="ri-music-line text-2xl text-cyan-400"></i>
                </div>
                <div>
                  <h3 className="text-white font-semibold text-lg mb-2">Muziek & Podcasts</h3>
                  <p className="text-gray-400 text-sm">Spotify, Apple Music en meer</p>
                </div>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.REACT_APP_NAVIGATE('/diensten-auto-upgrades-antwerpen')}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black px-8 py-4 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap cursor-pointer shadow-lg hover:shadow-cyan-500/30"
            >
              Meer Informatie
            </motion.button>
          </motion.div>

          {/* Right: Dashboard Mockup with Apple CarPlay */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative bg-gradient-to-br from-gray-900 to-black rounded-3xl p-8 border border-cyan-400/20 shadow-2xl shadow-cyan-400/20">
              {/* Dashboard Screen */}
              <div className="bg-black rounded-2xl overflow-hidden border border-gray-800">
                {/* Status Bar */}
                <div className="bg-gradient-to-b from-gray-900 to-black px-6 py-3 flex items-center justify-between border-b border-gray-800">
                  <div className="flex items-center space-x-2">
                    <span className="text-white text-sm font-medium">9:41</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <i className="ri-signal-wifi-fill text-white text-sm"></i>
                    <i className="ri-battery-fill text-white text-sm"></i>
                  </div>
                </div>

                {/* CarPlay Interface */}
                <div className="p-6 space-y-6">
                  {/* App Grid */}
                  <div className="grid grid-cols-4 gap-4">
                    {/* Apple Maps */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-map-pin-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Maps</span>
                    </motion.div>

                    {/* Apple Music */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-red-500 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-music-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Music</span>
                    </motion.div>

                    {/* Phone */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-700 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-phone-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Phone</span>
                    </motion.div>

                    {/* Messages */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-message-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Messages</span>
                    </motion.div>

                    {/* Spotify */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-spotify-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Spotify</span>
                    </motion.div>

                    {/* Podcasts */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-radio-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Podcasts</span>
                    </motion.div>

                    {/* Calendar */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-calendar-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Calendar</span>
                    </motion.div>

                    {/* Settings */}
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className="flex flex-col items-center space-y-2 cursor-pointer"
                    >
                      <div className="w-16 h-16 bg-gradient-to-br from-gray-600 to-gray-800 rounded-2xl flex items-center justify-center shadow-lg">
                        <i className="ri-settings-fill text-white text-2xl"></i>
                      </div>
                      <span className="text-white text-xs">Settings</span>
                    </motion.div>
                  </div>

                  {/* Now Playing Bar */}
                  <div className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-xl p-4 flex items-center space-x-4 border border-gray-700">
                    <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-red-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <i className="ri-music-fill text-white text-xl"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">Now Playing</p>
                      <p className="text-gray-400 text-xs truncate">Your Favorite Track</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-skip-back-fill text-white text-xl cursor-pointer hover:text-cyan-400"></i>
                      <i className="ri-play-circle-fill text-cyan-400 text-3xl cursor-pointer hover:text-cyan-300"></i>
                      <i className="ri-skip-forward-fill text-white text-xl cursor-pointer hover:text-cyan-400"></i>
                    </div>
                  </div>
                </div>
              </div>

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 to-blue-500/20 rounded-3xl blur-3xl -z-10"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

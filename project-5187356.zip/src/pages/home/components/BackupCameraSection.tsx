import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';

export default function BackupCameraSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start']
  });

  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center py-16 md:py-32 bg-black">
      <motion.div 
        style={{ opacity }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full"
      >
        <div className="grid lg:grid-cols-2 gap-10 md:gap-20 items-center">
          {/* Left - Camera Display */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative order-2 lg:order-1"
          >
            <div className="relative aspect-[4/3] bg-black rounded-2xl md:rounded-3xl overflow-hidden border-2 md:border-4 border-green-500/30 shadow-2xl shadow-green-500/20">
              {/* Camera View */}
              <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-gray-800">
                {/* Parking Lines */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  {/* Green safe zone */}
                  <motion.path
                    d="M 30 100 Q 50 70 70 100"
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="0.5"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  {/* Yellow caution zone */}
                  <motion.path
                    d="M 25 100 Q 50 60 75 100"
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="0.5"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 2, delay: 0.3, repeat: Infinity }}
                  />
                  {/* Red danger zone */}
                  <motion.path
                    d="M 20 100 Q 50 50 80 100"
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth="0.5"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 2, delay: 0.6, repeat: Infinity }}
                  />
                </svg>

                {/* Distance Indicators */}
                <div className="absolute bottom-4 md:bottom-8 left-1/2 -translate-x-1/2 flex gap-3 md:gap-6">
                  {[
                    { distance: '2.0m', color: 'text-green-400' },
                    { distance: '1.0m', color: 'text-yellow-400' },
                    { distance: '0.5m', color: 'text-red-400' },
                  ].map((indicator, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.2 }}
                      className={`${indicator.color} font-mono text-sm md:text-lg font-bold`}
                    >
                      {indicator.distance}
                    </motion.div>
                  ))}
                </div>

                {/* Camera Info */}
                <div className="absolute top-3 md:top-6 left-3 md:left-6 bg-black/50 backdrop-blur-md px-3 md:px-6 py-2 md:py-3 rounded-lg border border-white/10">
                  <p className="text-green-400 font-mono text-xs md:text-sm">ACHTERUITCAMERA ACTIEF</p>
                </div>

                {/* Sensors */}
                <div className="absolute top-3 md:top-6 right-3 md:right-6 flex gap-2 md:gap-3">
                  {[1, 2, 3, 4].map((i) => (
                    <motion.div
                      key={i}
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1.5, delay: i * 0.2, repeat: Infinity }}
                      className="w-2 h-2 md:w-3 md:h-3 bg-green-400 rounded-full"
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 blur-3xl -z-10"></div>
          </motion.div>

          {/* Right Content */}
          <div className="space-y-6 md:space-y-10 order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-8" style={{ fontFamily: 'Orbitron, monospace' }}>
                <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                  Achteruitcamera
                </span>
                <span className="text-white"> & Parkeersystemen</span>
              </h2>
              <p className="text-base sm:text-lg md:text-xl text-gray-400 leading-relaxed mb-6 md:mb-10">
                Parkeer met vertrouwen dankzij geavanceerde camera- en sensorsystemen. 
                Kristalheldere beelden en nauwkeurige afstandsmetingen.
              </p>
            </motion.div>

            {/* Features */}
            <div className="space-y-4 md:space-y-8">
              {[
                { icon: 'ri-camera-line', title: 'HD Camera Kwaliteit', desc: 'Scherpe beelden ook bij weinig licht' },
                { icon: 'ri-guide-line', title: 'Dynamische Parkeerlijnen', desc: 'Lijnen bewegen mee met stuurwiel' },
                { icon: 'ri-radar-line', title: 'Parkeersensoren', desc: 'Audio en visuele waarschuwingen' },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="flex items-start gap-3 md:gap-6"
                >
                  <div className="w-12 h-12 md:w-16 md:h-16 flex items-center justify-center bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-lg md:rounded-xl border border-green-500/30 flex-shrink-0">
                    <i className={`${feature.icon} text-2xl md:text-3xl text-green-400`}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg md:text-xl font-semibold text-white mb-1 md:mb-3">{feature.title}</h3>
                    <p className="text-gray-400 text-sm md:text-lg">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.REACT_APP_NAVIGATE('/diensten-auto-upgrades-antwerpen')}
              className="mt-6 md:mt-12 w-full sm:w-auto px-6 md:px-10 py-4 md:py-5 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-semibold rounded-xl text-base md:text-lg whitespace-nowrap cursor-pointer shadow-lg hover:shadow-green-500/30 transition-all duration-300"
            >
              Bekijk Installaties
            </motion.button>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
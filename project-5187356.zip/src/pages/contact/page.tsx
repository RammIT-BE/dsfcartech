import { useState } from 'react';
import Navigation from '../../components/feature/Navigation';
import Footer from '../../components/feature/Footer';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const formElement = e.target as HTMLFormElement;
      const formDataToSend = new URLSearchParams();
      
      formDataToSend.append('name', formData.name);
      formDataToSend.append('email', formData.email);
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('service', formData.service);
      formDataToSend.append('message', formData.message);

      const response = await fetch('https://readdy.ai/api/form/d4s4lh950n8gojamvoh0', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formDataToSend.toString()
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({
          name: '',
          email: '',
          phone: '',
          service: '',
          message: ''
        });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent">
            Contact
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Klaar om uw auto te upgraden? Neem contact op voor een gratis consultatie 
            en persoonlijk advies over de beste oplossing voor uw voertuig.
          </p>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            
            {/* Contact Form */}
            <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800">
              <h2 className="text-2xl font-bold text-white mb-6">Stuur ons een bericht</h2>
              
              {submitStatus === 'success' && (
                <div className="mb-6 p-4 bg-green-500/20 border border-green-500/50 rounded-lg text-green-400">
                  <i className="ri-check-line mr-2"></i>
                  Bedankt voor uw bericht! We nemen binnen 24 uur contact met u op.
                </div>
              )}
              
              {submitStatus === 'error' && (
                <div className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400">
                  <i className="ri-error-warning-line mr-2"></i>
                  Er is iets misgegaan. Probeer het opnieuw of bel ons direct.
                </div>
              )}

              <form id="contact_form" data-readdy-form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                      Naam *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none transition-colors"
                      placeholder="Uw volledige naam"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                      E-mail *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none transition-colors"
                      placeholder="uw.email@example.com"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-2">
                      Telefoon
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none transition-colors"
                      placeholder="+32 123 45 67 89"
                    />
                  </div>
                  <div>
                    <label htmlFor="service" className="block text-sm font-medium text-gray-300 mb-2">
                      Gewenste Service
                    </label>
                    <select
                      id="service"
                      name="service"
                      value={formData.service}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none transition-colors"
                    >
                      <option value="">Selecteer een service</option>
                      <option value="carplay">CarPlay & Android Auto</option>
                      <option value="starroof">Sterrenhemel / Starroof</option>
                      <option value="ambient">Sfeerverlichting</option>
                      <option value="camera">Achteruitcamera & Parkeersystemen</option>
                      <option value="custom">Maatwerk oplossing</option>
                      <option value="consultation">Gratis consultatie</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                    Bericht *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    maxLength={500}
                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none transition-colors resize-none"
                    placeholder="Vertel ons over uw auto en wat u graag zou willen upgraden..."
                  ></textarea>
                  <div className="text-right text-sm text-gray-400 mt-1">
                    {formData.message.length}/500
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 disabled:from-gray-600 disabled:to-gray-700 text-black font-semibold py-4 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 disabled:scale-100 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer shadow-lg hover:shadow-cyan-500/30"
                >
                  {isSubmitting ? (
                    <>
                      <i className="ri-loader-4-line animate-spin mr-2"></i>
                      Versturen...
                    </>
                  ) : (
                    <>
                      <i className="ri-send-plane-line mr-2"></i>
                      Bericht Versturen
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              
              {/* Quick Contact */}
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800">
                <h3 className="text-2xl font-bold text-white mb-6">Direct Contact</h3>
                
                <div className="space-y-6">
                  <a href="tel:0489170592" className="flex items-center group cursor-pointer">
                    <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center mr-4 group-hover:scale-110 transition-transform duration-300">
                      <i className="ri-phone-line text-black text-xl"></i>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Bel ons direct</p>
                      <p className="text-white font-semibold text-lg">0489 17 05 92</p>
                    </div>
                  </a>
                  
                  <a href="https://wa.me/32489170592" target="_blank" rel="noopener noreferrer" className="flex items-center group cursor-pointer">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mr-4 group-hover:scale-110 transition-transform duration-300">
                      <i className="ri-whatsapp-line text-white text-xl"></i>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">WhatsApp</p>
                      <p className="text-white font-semibold text-lg">0489 17 05 92</p>
                    </div>
                  </a>
                  
                  <a href="mailto:info@dsfcartech.be" className="flex items-center group cursor-pointer">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center mr-4 group-hover:scale-110 transition-transform duration-300">
                      <i className="ri-mail-line text-white text-xl"></i>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">E-mail</p>
                      <p className="text-white font-semibold text-lg">info@dsfcartech.be</p>
                    </div>
                  </a>
                </div>
              </div>

              {/* Location Info */}
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800">
                <h3 className="text-2xl font-bold text-white mb-6">Bezoek Onze Werkplaats</h3>
                
                <div className="space-y-4 mb-6">
                  <div className="flex items-start">
                    <i className="ri-map-pin-line text-cyan-400 text-xl mr-3 mt-1"></i>
                    <div>
                      <p className="text-white font-medium">DSF Cartech</p>
                      <p className="text-gray-300">Ternesselei 191</p>
                      <p className="text-gray-300">2160 Wommelgem, België</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <i className="ri-time-line text-cyan-400 text-xl mr-3 mt-1"></i>
                    <div>
                      <p className="text-white font-medium mb-2">Openingstijden</p>
                      <div className="text-gray-300 text-sm space-y-1">
                        <p>Maandag - Vrijdag: 08:00 - 18:00</p>
                        <p>Zaterdag: 09:00 - 16:00</p>
                        <p>Zondag: Gesloten</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <a
                  href="https://www.google.com/maps/dir//Ternesselei+191,+2160+Wommelgem"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-black font-semibold py-3 px-6 rounded-xl transition-all duration-300 flex items-center justify-center whitespace-nowrap cursor-pointer shadow-lg hover:shadow-cyan-500/30 hover:scale-105"
                >
                  <i className="ri-navigation-line mr-2"></i>
                  Route Plannen
                </a>
              </div>

              {/* FAQ Quick Links */}
              <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800">
                <h3 className="text-2xl font-bold text-white mb-6">Veelgestelde Vragen</h3>
                
                <div className="space-y-3">
                  {[
                    'Hoe lang duurt een CarPlay installatie?',
                    'Krijg ik garantie op de installatie?',
                    'Kan ik mijn auto tijdens de installatie gebruiken?',
                    'Welke auto merken ondersteunen jullie?'
                  ].map((question, index) => (
                    <div key={index} className="flex items-center text-gray-300 hover:text-cyan-400 cursor-pointer transition-colors">
                      <i className="ri-question-line mr-3 text-cyan-400"></i>
                      <span className="text-sm">{question}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 px-4 bg-gray-900/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-white">
            Vind Ons in Antwerpen
          </h2>
          
          <div className="relative rounded-2xl overflow-hidden">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2499.123456789!2d4.4024!3d51.2194!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTHCsDEzJzA5LjgiTiA0wrAyNCcwOC43IkU!5e0!3m2!1snl!2sbe!4v1234567890"
              width="100%"
              height="500"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
            
            <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg p-4 text-white">
              <h4 className="font-bold mb-2">DSF Cartech</h4>
              <p className="text-sm text-gray-300">Ternesselei 191, Wommelgem</p>
              <p className="text-sm text-cyan-400">0489 17 05 92</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ContactPage;